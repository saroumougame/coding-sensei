# Sortable with custom ImageComponent

Using [react-sortable-hoc](https://github.com/clauderic/react-sortable-hoc) we can reorder the Gallery using drag and drop.  This requires you to use Gallery's custom ImageComponent prop because it will need to be passed into the SortableElement HOC. 

<iframe src="https://codesandbox.io/embed/8y7n1r9y5j?hidenavigation=1&view=preview" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
