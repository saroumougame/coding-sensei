There is an example app that comes with the project. To build the examples locally [clone the repo](https://github.com/neptunian/react-photo-gallery), cd into the project directory and run:



```
yarn install
yarn start
```



Navigate to localhost:8000 in a browser.
```
```
