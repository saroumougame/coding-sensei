# Basic w/ Columns

Example using the most basic required properties.  Pass `column` to Gallery's `direction` prop to achieve the masonry layout.

<iframe src="https://codesandbox.io/embed/r09k1xj614?hidenavigation=1&view=preview" style="width:100%; height:500px; border:0; border-radius: 4px; overflow:hidden;" sandbox="allow-modals allow-forms allow-popups allow-scripts allow-same-origin"></iframe>
